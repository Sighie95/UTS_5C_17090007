<?php 
	
	require '../koneksi.php';
	$produk = mysqli_query($koneksi,"SELECT * FROM tb_produk");
	
	
 ?>
<div class="container-fluid">
	<h3><i class="fas fa-ad mr-2 mt-4"></i>Data Produk</h3><hr>

	<a href="?page=tambah_produk" class="btn btn-primary mb-3"><i class="fas fa-plus-circle mr-2"></i>Tambah Data</a>

	<!-- <div class="table-wrapper-scroll-y my-custom-scrollbar"> -->
	<div class="table-responsive">
		<table  id="dtHorizontalVerticalScrollExample" class="table table-bordered table-striped table-sm" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>No</th>
					<th>Opsi</th>
					<th>Nama</th>
					<th>Deskripsi</th>
					<th>Harga</th>
					<th>Kategori</th>
					<th>Gambar</th>
				</tr>
			</thead>
			<tbody>
				<tr>
				<?php $nomor = 1; ?>
				<?php while ($data = mysqli_fetch_assoc($produk)) { ?>
					<td><?php echo $nomor; ?></td>
					<td>
						<a href="?page=ubah_produk&id=<?php echo $data['id_produk']; ?>" class="btn btn-success mt-2"><i class="fas fa-edit"></i></a>
						<a href="?page=hapus_produk&id=<?php echo $data['id_produk']; ?>" class="btn btn-danger mt-2"><i class="fas fa-trash-alt"></i></a>
					</td>
					<td><?php echo $data['nama']; ?></td>
					<td><?php echo $data['deskripsi']; ?></td>
					<td><?php echo $data['harga']; ?></td>
					<td><?php echo $data['kategori']; ?></td>
					<td>
						<img src="../gambar/<?php echo$data['gambar']; ?>" width="200">
					</td>
				</tr>
				<?php 
					$nomor++;
				} ?>
			</tbody>
		</table>
	</div>
</div>