<div class="container-fluid">
	<h3><i class="fas fa-user mr-2 mt-4"></i>Tambah Data User</h3><hr><hr>

	<?php 
			
		If (isset($_POST['save'])) 
		 	{
		 		$username = $_POST['username'];
		 		$password = md5($_POST['password']);
		 		$nama = $_POST['nama'];
		 		$level = $_POST['level'];
		 		
		 		$query = "INSERT INTO user(username,password,nama,level)
		 				VALUES ('$username','$password','$nama','$level')";
		 		$save = mysqli_query($koneksi,$query);

		 		if ($save) {
		 			echo "<div class=\"alert alert-success\" role=\"alert\">Berhasil Disimpan</div>";
					echo "<script>var timer = setTimeout(function()
					{ window.location= '?page=data_user'}, 1000);
				</script>";
				}else{
					echo "<div class=\"alert alert-danger\" role=\"alert\">Gagal disimpan</div>";
					echo "<script>var timer = setTimeout(function()
					{ window.location= '?page=tambah_user'}, 1000);
				</script>";
		 		}
		 	}

	?>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label>Username</label>
				<input type="text" class="form-control" name="username" required>
			</div>
			<div class="form-group">
				<label>Password</label>
				<input type="password" class="form-control" name="password" required>
			</div>
			<div class="form-group">
				<label>Nama</label>
				<input type="text" class="form-control" name="nama" required>
			</div>
			<div class="form-group">
				<label>Level</label>
				<select required="" class="form-control" name="level" required>
					<option>--Plih Salah Satu--</option>
					<option>Admin</option>
					<option>Guest</option>
				</select>
			</div>
			<button class="btn btn-success" name="save">Simpan</button>
		</form>
</div>