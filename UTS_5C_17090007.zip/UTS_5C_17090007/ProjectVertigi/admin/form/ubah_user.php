<div class="container-fluid">
	<h3><i class="fas fa-user mr-2 mt-4"></i>Edit Data User</h3><hr><hr>

	<?php 
			
		If (isset($_POST['edit'])) 
		 	{
		 		$username = $_POST['username'];
		 		$password = md5($_POST['password']);
		 		$pass = $_POST['password'];
		 		$nama = $_POST['nama'];
		 		$level = $_POST['level'];
		 		
		 		$query = "UPDATE user SET username = '$username', password = '$password' , nama ='$nama',level ='$level'
		 				WHERE id_user = '$_GET[id]'";
		 		$save = mysqli_query($koneksi,$query);

		 		if ($save) {
		 			echo "<div class=\"alert alert-success\" role=\"alert\">Berhasil disimpan</div>";
					echo "<script>var timer = setTimeout(function()
					{ window.location= '?page=data_user'}, 1000);
				</script>";
				}else{
					echo "<div class=\"alert alert-danger\" role=\"alert\">Gagal disimpan</div>";
					echo "<script>var timer = setTimeout(function()
					{ window.location= '?page=ubah_user'}, 1000);
				</script>";
		 		}
		 	}
		 ?>


		<?php 
		
			$ambil = "SELECT * FROM user WHERE id_user='$_GET[id]'";
			$edit = mysqli_query($koneksi,$ambil);
			$data = mysqli_fetch_assoc($edit);


 		?>


	
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label>Username</label>
				<input type="text" class="form-control" name="username" value="<?php echo $data['username']; ?>">
			</div>
			<div class="form-group">
				<label>Password</label><p style="color: red;">Mohon di isi kembali</p>
				<input type="password" class="form-control" name="password" required ><!-- value="<?php echo $data['pass']; ?>" -->
			</div>
			<div class="form-group">
				<label>Nama</label>
				<input type="text" class="form-control" name="nama" value="<?php echo $data['nama']; ?>">
			</div>
			<div class="form-group">
				<label>Level</label>
				<select required="" class="form-control" name="level" required>
					<option value="<?php echo $data['level']; ?>"><?php echo $data['level']; ?></option>
					<option>Admin</option>
					<option>Guest</option>
				</select>
			</div>
			<button class="btn btn-success" name="edit">Simpan</button>
		</form>
</div>