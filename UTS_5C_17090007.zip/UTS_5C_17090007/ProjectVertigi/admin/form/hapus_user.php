<div class="container-fluid">
	<h3><i class="fas fa-user mr-2 mt-4"></i>Data User</h3><hr>

	<?php  
	
	require '../koneksi.php';

	$query = "DELETE FROM user WHERE id_user='$_GET[id]'";
	$delete = mysqli_query($koneksi,$query);

	if ($delete) {
		echo "<div class=\"alert alert-success\" role=\"alert\">Berhasil dihapus</div>";
		echo "<script>var timer = setTimeout(function()
			{ window.location= '?page=data_user'}, 500);
			</script>";
	}else{
		echo "<div class=\"alert alert-danger\" role=\"alert\">Gagal dihapus</div>";
		echo "<script>var timer = setTimeout(function()
		{ window.location= '?page=data_user'}, 500);
		</script>";
	}

 ?>

</div>