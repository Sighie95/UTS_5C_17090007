<div class="container-fluid">
 	<h3><i class="fas fa-briefcase mr-2 mt-4"></i>Tambah Data Keahlian</h3><hr><hr>

 	<?php 
			
		If (isset($_POST['save'])) 
		 	{
		 		$kategori = $_POST['kategori'];
		 		
		 		
		 		$query = "INSERT INTO tb_kategori(kategori)
		 				VALUES ('$kategori')";
		 		$save = mysqli_query($koneksi,$query);

		 		if ($save) {
		 			// echo "<script>alert('Data Berhasil Tersimpan');</script>";
		 			echo "<div class=\"alert alert-success\" role=\"alert\">Berhasil disimpan</div>";
					echo "<script>var timer = setTimeout(function()
					{ window.location= '?page=data_kategori'}, 1000);
				</script>";
				}else{
					// echo "<script>alert('Data Gagal Tersimpan');</script>";
					echo "<div class=\"alert alert-danger\" role=\"alert\">Gagal disimpan</div>";
					echo "<script>var timer = setTimeout(function()
					{ window.location= '?page=tambah_kategori'}, 1000);
				</script>";
		 		}
		 	}

	?>


	<form method="post" enctype="multipart/form-data" action="">
			<div class="form-group">
				<label>Keahlian</label>
				<input type="text" class="form-control" name="kategori" required>
			</div>
			<button class="btn btn-success" name="save">Simpan</button>
	</form>

</div>