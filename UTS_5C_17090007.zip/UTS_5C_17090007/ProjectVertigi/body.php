<body>
	<?php 
		require 'partials/navbar.php';
		// require 'content/home.php';
	 ?>

	 <?php 
	 	$content = (isset($_GET["page"])) ? $_GET["page"] : "";

	 	switch ($content) {
	 		case 'produk':
	 			echo "<title>Produk Vertigi Musik</title>";
	 			require 'content/produk.php';
	 			break;

	 		case 'detail_produk':
	 			echo "<title>Produk Vertigi Musik</title>";
	 			require 'content/detail_produk.php';
	 			break;

	 		case 'about_us':
	 			echo "<title>about_us Vertigi Musik</title>";
	 			require 'content/about_us.php';
	 			break;

	 		case 'contact':
	 			echo "<title>contact Vertigi Musik</title>";
	 			require 'content/contact.php';
	 			break;
	 		
	 		default:
	 			echo "<title>Vertigi Musik</title>";
	 			require 'content/home.php';
	 			break;
	 	}
	  ?>

	 <?php 
	 	require 'partials/footer.php';
	  ?>


</body>