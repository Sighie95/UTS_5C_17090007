<!DOCTYPE html>
<html>

<?php 
require 'koneksi.php';

require 'partials/header.php';
require 'body.php';
 ?>

</html>